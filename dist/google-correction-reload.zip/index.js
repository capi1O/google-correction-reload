// override "Showing results for ..." link click event
document.getElementById("fprsl").onclick = function() {};
